import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class GUI {
    public static void main(String[] args) {
        Controller control = new Controller();
        JFrame ventana = new JFrame("SAFA-Ntra.Sra. de los Reyes");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(900, 900);
        ventana.setResizable(false);
        ventana.getRootPane().setBorder(new EmptyBorder(20, 20, 20 ,20));

        JLabel titulo = new JLabel("GESTIÓN SAFA FCT", SwingConstants.CENTER);
        titulo.setFont(new Font("Verdana", Font.BOLD,20));
        JPanel botonera = new JPanel();
        JButton btnGestion = new JButton("Gestión Empresas");
        JButton btnAsignacion = new JButton("Asignación Alumnos");
        JButton btnFicheros = new JButton("Ficheros a Tabla");
        botonera.add(btnGestion);
        botonera.add(btnAsignacion);
        botonera.add(btnFicheros);

        JPanel inicio = new JPanel();
        JLabel logoSafa = new JLabel(new ImageIcon("resources/logoSafa.png"), SwingConstants.CENTER);
        inicio.add(logoSafa);

        JPanel gestionEmpresa = new JPanel(new GridLayout(10,1));
        gestionEmpresa.setBorder(new EmptyBorder(80, 30, 80, 0));
        JLabel codEmpresa = new JLabel("Código Empresa: ");
        JLabel nomEmpresa = new JLabel("Nombre Empresa: ");
        JLabel cif = new JLabel("CIF: ");
        JLabel direccion = new JLabel("Dirección: ");
        JLabel cp = new JLabel("C.P: ");
        JLabel localidad = new JLabel("Localidad: ");
        JLabel tipoJornada = new JLabel("Tipo de jornada: ");
        JLabel dniResponsable = new JLabel("DNI del responsable: ");
        JLabel nombreResponsable = new JLabel("Nombre del responsable: ");
        JLabel apellidosResponsable = new JLabel("Apellidos del responsable: ");
        JLabel dniTutor = new JLabel("DNI del tutor laboral: ");
        JLabel nombreTutor = new JLabel("Nombre del tutor laboral: ");
        JLabel apellidosTutor = new JLabel("Apellidos del tutor laboral: ");
        JLabel mailTutor = new JLabel("Mail del tutor laboral: ");
        JLabel telefonoTutor = new JLabel("Teléfono del tutor: ");
        JTextField campoCodEmpresa = new JTextField(6);
        JTextField campoNomEmpresa = new JTextField(10);
        JTextField campocif = new JTextField(6);
        JTextField campoDireccion = new JTextField(15);
        JTextField campoCp = new JTextField(5);
        JTextField campoLocalidad = new JTextField(10);
        JComboBox campoJornada = new JComboBox();
        campoJornada.addItem("partida");
        campoJornada.addItem("continua");
        JTextField campoDniRes = new JTextField(7);
        JTextField campoNomRes = new JTextField(6);
        JTextField campoApellRes = new JTextField(15);
        JTextField campoDniTutor = new JTextField(7);
        JTextField campoNomTutor = new JTextField(6);
        JTextField campoApellTutor = new JTextField(15);
        JTextField campoMailTutor = new JTextField(20);
        JTextField campoTelefTutor = new JTextField(10);
        JButton btnInsertar = new JButton("Insertar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnBorrar = new JButton("Borrar");
        JPanel celda1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        celda1.add(codEmpresa);
        celda1.add(campoCodEmpresa);
        celda1.add(nomEmpresa);
        celda1.add(campoNomEmpresa);
        JPanel celda2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        celda2.add(cif);
        celda2.add(campocif);
        celda2.add(direccion);
        celda2.add(campoDireccion);
        JPanel celda3 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        celda3.add(cp);
        celda3.add(campoCp);
        celda3.add(localidad);
        celda3.add(campoLocalidad);
        celda3.add(tipoJornada);
        celda3.add(campoJornada);
        JPanel celda4 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        celda4.add(dniResponsable);
        celda4.add(campoDniRes);
        celda4.add(nombreResponsable);
        celda4.add(campoNomRes);
        celda4.add(apellidosResponsable);
        celda4.add(campoApellRes);
        JPanel celda5 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        celda5.add(dniTutor);
        celda5.add(campoDniTutor);
        celda5.add(nombreTutor);
        celda5.add(campoNomTutor);
        celda5.add(apellidosTutor);
        celda5.add(campoApellTutor);
        JPanel celda6 = new JPanel(new FlowLayout(FlowLayout.LEFT));
        celda6.add(mailTutor);
        celda6.add(campoMailTutor);
        celda6.add(telefonoTutor);
        celda6.add(campoTelefTutor);
        JPanel celda7 = new JPanel();
        celda7.add(btnInsertar);
        celda7.add(btnModificar);
        celda7.add(btnBorrar);
        JTable tabla = new JTable();
        JScrollPane celda8 = new JScrollPane(tabla);
        gestionEmpresa.add(celda1);
        gestionEmpresa.add(celda2);
        gestionEmpresa.add(celda3);
        gestionEmpresa.add(celda4);
        gestionEmpresa.add(celda5);
        gestionEmpresa.add(celda6);
        gestionEmpresa.add(celda7);
        gestionEmpresa.add(celda8);

        JPanel asignacionAlumnos = new JPanel(new GridLayout(5,1));
        asignacionAlumnos.setBorder(new EmptyBorder(80, 30, 80, 0));
        JLabel alumno = new JLabel("Elección de Alumno: ");
        JLabel empresa = new JLabel("Elección de Empresa: ");
        JLabel tutor = new JLabel("Elección de Tutor: ");
        JComboBox desplegableAlum = new JComboBox();
        desplegableAlum.setPreferredSize(new Dimension(200, 25));
        JComboBox desplegableEmp = new JComboBox();
        desplegableEmp.setPreferredSize(new Dimension(100, 25));
        JComboBox desplegableTutor = new JComboBox();
        desplegableTutor.setPreferredSize(new Dimension(150, 25));
        JTextArea comentario = new JTextArea(3,30);
        comentario.setLineWrap(true);
        comentario.setWrapStyleWord(true);
        comentario.setEditable(false);
        comentario.setPreferredSize(new Dimension(600, 60));
        JButton btnAsignar = new JButton("Asignar");
        JPanel linea1 = new JPanel();
        linea1.add(alumno);
        linea1.add(desplegableAlum);
        JPanel linea2 = new JPanel();
        linea2.add(empresa);
        linea2.add(desplegableEmp);
        JPanel linea3 = new JPanel();
        linea3.add(tutor);
        linea3.add(desplegableTutor);
        JPanel linea4 = new JPanel();
        linea4.add(comentario);
        JPanel linea5 = new JPanel();
        linea5.add(btnAsignar);
        asignacionAlumnos.add(linea1);
        asignacionAlumnos.add(linea2);
        asignacionAlumnos.add(linea3);
        asignacionAlumnos.add(linea4);
        asignacionAlumnos.add(linea5);

        JPanel ficheroTabla = new JPanel(new BorderLayout());
        JLabel logoBase = new JLabel(new ImageIcon("resources/base.png"), SwingConstants.CENTER);
        JButton vincular = new JButton("Vincular");
        ficheroTabla.add(logoBase,BorderLayout.CENTER);
        ficheroTabla.add(vincular,BorderLayout.SOUTH);

        JPanel base = new JPanel();
        CardLayout tarjetas = new CardLayout();
        base.setLayout(tarjetas);
        base.add(inicio,"1");
        base.add(gestionEmpresa,"2");
        base.add(asignacionAlumnos,"3");
        base.add(ficheroTabla,"4");
        tarjetas.show(base,"1");

        ventana.add(titulo, BorderLayout.NORTH);
        ventana.add(base, BorderLayout.CENTER);
        ventana.add(botonera, BorderLayout.SOUTH);
        ventana.setVisible(true);

        btnGestion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                titulo.setText("GESTIÓN DE LAS EMPRESAS DEL PROGRAMA FCT");
                tarjetas.show(base,"2");
                tabla.setModel(control.construyeTabla());
            }
        });
        btnAsignacion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                titulo.setText("ASIGNACIÓN DE ALUMNOS A EMPRESAS");
                tarjetas.show(base,"3");
                ResultSet resultadoAlum = null;
                ResultSet resultadoEm = null;
                ResultSet resultadoProf = null;
                desplegableAlum.removeAllItems();
                desplegableEmp.removeAllItems();
                desplegableTutor.removeAllItems();
                try {
                    resultadoAlum = control.rellenarComboboxAlum();
                    resultadoEm = control.rellenarComboboxEm();
                    resultadoProf = control.rellenarComboboxProf();
                    while(resultadoAlum.next()) {
                        desplegableAlum.addItem(resultadoAlum.getString("codigoAlumno") + "-" + resultadoAlum.getString("nombre") + " " + resultadoAlum.getString("apellidos"));
                    }
                    while(resultadoEm.next()) {
                        desplegableEmp.addItem(resultadoEm.getString("codigoEmpresa") + "-" + resultadoEm.getString("razonSocial"));
                    }
                    while(resultadoProf.next()) {
                        desplegableTutor.addItem(resultadoProf.getString("codigoTutor") + "-" + resultadoProf.getString("nombre") + " " + resultadoProf.getString("apellidos"));
                    }
                }catch (SQLException ex) {
                        ex.printStackTrace();
                }
            }
        });
        btnAsignar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nomAlum = desplegableAlum.getSelectedItem().toString();
                String nomEm = desplegableEmp.getSelectedItem().toString();
                String nomTutor = desplegableTutor.getSelectedItem().toString();
                int codAlum = Integer.parseInt(nomAlum.split("-")[0]);
                int codEm = Integer.parseInt(nomEm.split("-")[0]);
                int codTutor = Integer.parseInt(nomTutor.split("-")[0]);
                String nomRes = control.extraerNomRes(codEm);
                String mensaje = "El alumno " + nomAlum + ", queda asignado a la empresa " + nomEm + " supervisados por los tutores " + nomTutor + " (docente) y " + nomRes + " (laboral).";
                comentario.setText(mensaje);
                control.insertarAsignacion(codEm, codAlum, codTutor, mensaje);
            }
        });
        btnFicheros.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                titulo.setText("ALUMNOS Y TUTORES A TABLA");
                tarjetas.show(base,"4");
            }
        });
        vincular.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                control.vinculoXML();
                control.vinculoDAT();
            }
        });
        btnInsertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int valCod;
                String valRazon,  valCif,   valDireccion,  valCp,  valLocalidad,  valJornada,  valDniRes,  valNomRes,  valApellRes,  valDniTutor,  valNomTutor,  valApellTutor,  valMailTutor,  valTelefTutor;

                valCod = Integer.parseInt(campoCodEmpresa.getText());
                valRazon = campoNomEmpresa.getText();
                valCif = campocif.getText();
                valDireccion = campoDireccion.getText();
                valCp = campoCp.getText();
                valLocalidad = campoLocalidad.getText();
                valJornada = campoJornada.getSelectedItem().toString();
                valDniRes = campoDniRes.getText();
                valNomRes = campoNomRes.getText();
                valApellRes = campoApellRes.getText();
                valDniTutor = campoDniTutor.getText();
                valNomTutor = campoNomTutor.getText();
                valApellTutor = campoApellTutor.getText();
                valMailTutor = campoMailTutor.getText();
                valTelefTutor = campoTelefTutor.getText();
                control.insercionEmpresa(valCod, valRazon, valCif, valDireccion, valCp, valLocalidad, valJornada, valDniRes, valNomRes, valApellRes, valDniTutor, valNomTutor, valApellTutor, valMailTutor, valTelefTutor);
                tabla.setModel(control.construyeTabla());
            }
        });
        btnModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int valCod;
                String valRazon,  valCif,   valDireccion,  valCp,  valLocalidad,  valJornada,  valDniRes,  valNomRes,  valApellRes,  valDniTutor,  valNomTutor,  valApellTutor,  valMailTutor,  valTelefTutor;

                valCod = Integer.parseInt(campoCodEmpresa.getText());
                valRazon = campoNomEmpresa.getText();
                valCif = campocif.getText();
                valDireccion = campoDireccion.getText();
                valCp = campoCp.getText();
                valLocalidad = campoLocalidad.getText();
                valJornada = campoJornada.getSelectedItem().toString();
                valDniRes = campoDniRes.getText();
                valNomRes = campoNomRes.getText();
                valApellRes = campoApellRes.getText();
                valDniTutor = campoDniTutor.getText();
                valNomTutor = campoNomTutor.getText();
                valApellTutor = campoApellTutor.getText();
                valMailTutor = campoMailTutor.getText();
                valTelefTutor = campoTelefTutor.getText();
                control.modificacionEmpresa(valCod, valRazon, valCif, valDireccion, valCp, valLocalidad, valJornada, valDniRes, valNomRes, valApellRes, valDniTutor, valNomTutor, valApellTutor, valMailTutor, valTelefTutor);
                tabla.setModel(control.construyeTabla());
            }
        });
        btnBorrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int valCod;

                valCod = Integer.parseInt(campoCodEmpresa.getText());
                control.eliminacionEmpresa(valCod);
                tabla.setModel(control.construyeTabla());
            }
        });
    }
}