CREATE DATABASE proy3te4;
USE proy3te4;

CREATE TABLE empresas (
	codigoEmpresa INT PRIMARY KEY,
	razonSocial VARCHAR(100) NOT NULL,
	cif CHAR(9) NOT NULL UNIQUE,
	direccion VARCHAR(100) NOT NULL,
	cp CHAR(5) NOT NULL,
	localidad VARCHAR(50) NOT NULL,
	tipoJornada CHAR(8) NOT NULL,
	dniResponsable CHAR(9) NOT NULL UNIQUE,
	nombreResponsable VARCHAR(50) NOT NULL,
	apellidosResponsable VARCHAR(100) NOT NULL,
	dniTutorLaboral CHAR(9) NOT NULL,
	nombreTutorLaboral VARCHAR(50) NOT NULL,
	apellidosTutorLaboral VARCHAR(100) NOT NULL,
	mailTutorLaboral VARCHAR(200) NOT NULL,
	telefonoTutorLaboral CHAR(9) NOT NULL,
	CONSTRAINT jornada CHECK (tipoJornada IN ("partida","continua"))
);

CREATE TABLE alumnos (
	codigoAlumno INT PRIMARY KEY,
	dni CHAR(9) NOT NULL UNIQUE,
	nombre VARCHAR(50) NOT NULL,
	apellidos VARCHAR(100) NOT NULL,
	fechaNacimiento DATE NOT NULL
);

CREATE TABLE tutores (
	codigoTutor INT PRIMARY KEY,
	nombre VARCHAR(50) NOT NULL,
	apellidos VARCHAR(100) NOT NULL,
	correoElectronico VARCHAR(200) NOT NULL,
	telefono CHAR(9) NOT NULL
);

CREATE TABLE asignados (
	codigoEmpresa INT,
	codigoAlumno INT,
	codigoTutor INT,
	descripción VARCHAR(500) NOT NULL,
	PRIMARY KEY (codigoEmpresa, codigoAlumno, codigoTutor),
	FOREIGN KEY (codigoEmpresa) REFERENCES empresas(codigoEmpresa) ON DELETE CASCADE,
	FOREIGN KEY (codigoAlumno) REFERENCES alumnos(codigoAlumno) ON DELETE CASCADE,
	FOREIGN KEY (codigoTutor) REFERENCES tutores(codigoTutor) ON DELETE CASCADE
);