/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog3t_javafx;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Usuario
 */
public class FXMLDocumentController implements Initializable {
    
    public Connection conexion = null;
    public PreparedStatement st = null;
    
    private Label label;
    ObservableList<TablaModelo> listaEmpresa = FXCollections.observableArrayList();
    @FXML
    private TableView<TablaModelo> tablaEmpresa;
    @FXML
    private TableColumn<TablaModelo, String> codEm;
    @FXML
    private TableColumn<TablaModelo, String> razonSocial;
    @FXML
    private TableColumn<TablaModelo, String> nomRes;
    @FXML
    private TableColumn<TablaModelo, String> nomTutor;
    @FXML
    private Button btnInsertar;
    @FXML
    private Button btnModificar;
    @FXML
    private Button btnConsultar;
    @FXML
    private Button btnBorrar;
    @FXML
    private TextField campoCodEm;
    @FXML
    private TextField campoNomEm;
    @FXML
    private TextField campoCif;
    @FXML
    private TextField campoDireccion;
    @FXML
    private TextField campoCp;
    @FXML
    private TextField campoLocalidad;
    @FXML
    private ComboBox<String> campoJornada;
    @FXML
    private TextField campoDniRes;
    @FXML
    private TextField campoNomRes;
    @FXML
    private TextField campoApellRes;
    @FXML
    private TextField campoDniTutor;
    @FXML
    private TextField campoNomTutor;
    @FXML
    private TextField campoApellTutor;
    @FXML
    private TextField campoMailTutor;
    @FXML
    private TextField campoTelTutor;
    ObservableList comboAlum = FXCollections.observableArrayList();
    @FXML
    private ComboBox<?> campoEleccionAlum;
    ObservableList comboEm = FXCollections.observableArrayList();
    @FXML
    private ComboBox<?> campoEleccionEm;
    ObservableList comboTutor = FXCollections.observableArrayList();
    @FXML
    private ComboBox<?> campoEleccionTutor;
    @FXML
    private TextArea campoMensaje;
    @FXML
    private Button btnAsignar;
    @FXML
    private Button btnVincular;
    
    public void construyeTabla() {
        ResultSet resul = null;
        tablaEmpresa.getItems().clear();
        try { 
            st = conexion.prepareStatement("SELECT codigoEmpresa, razonSocial, nombreResponsable, nombreTutorLaboral FROM empresas");
            resul = st.executeQuery();
            while (resul.next()) {
                listaEmpresa.add(new TablaModelo(resul.getInt("codigoEmpresa"), resul.getString("razonSocial"), resul.getString("nombreResponsable"), resul.getString("nombreTutorLaboral")));
            }
        }catch(SQLException e) {
            e.printStackTrace();
        }
        codEm.setCellValueFactory(new PropertyValueFactory<>("codigoEmpresa"));
        razonSocial.setCellValueFactory(new PropertyValueFactory<>("nombreEmpresa"));
        nomRes.setCellValueFactory(new PropertyValueFactory<>("nombreResponsable"));
        nomTutor.setCellValueFactory(new PropertyValueFactory<>("nombreTutor"));
        tablaEmpresa.setItems(listaEmpresa);
    }
    
    public void construyeComboAlum() {
        ResultSet resul = null;
        campoEleccionAlum.getItems().clear();
        try {
            st = conexion.prepareStatement("SELECT codigoAlumno, nombre, apellidos FROM alumnos");
            resul = st.executeQuery();
            while(resul.next()) {
                comboAlum.add(resul.getString("codigoAlumno") + "-" + resul.getString("nombre") + " " + resul.getString("apellidos"));
            }
        }catch(SQLException e) {
            e.printStackTrace();
        }
        campoEleccionAlum.setItems(comboAlum);
    }
    
    public void construyeComboEm() {
        ResultSet resul = null;
        campoEleccionEm.getItems().clear();
        try {
            st = conexion.prepareStatement("SELECT codigoEmpresa, razonSocial FROM empresas");
            resul = st.executeQuery();
            while(resul.next()) {
                comboEm.add(resul.getString("codigoEmpresa") + "-" + resul.getString("razonSocial"));
            }
        }catch(SQLException e) {
            e.printStackTrace();
        }
        campoEleccionEm.setItems(comboEm);
    }
    
    public void construyeComboTutor() {
        ResultSet resul = null;
        campoEleccionTutor.getItems().clear();
        try {
            st = conexion.prepareStatement("SELECT codigoTutor, nombre, apellidos FROM tutores");
            resul = st.executeQuery();
            while(resul.next()) {
                comboTutor.add(resul.getString("codigoTutor") + "-" + resul.getString("nombre") + " " + resul.getString("apellidos"));
            }
        }catch(SQLException e) {
            e.printStackTrace();
        }
        campoEleccionTutor.setItems(comboTutor);
    }
    
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            Class.forName("org.mariadb.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mariadb://localhost:3306/proy3te4", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        construyeTabla();
        construyeComboAlum();
        construyeComboEm();
        construyeComboTutor();       
    }    

    @FXML
    private void insertarEmpresa(ActionEvent event) {
        int filas = 0;
        try {
            st = conexion.prepareStatement("INSERT INTO empresas VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            st.setInt(1, Integer.parseInt(campoCodEm.getText()));
            st.setString(2,campoNomEm.getText());
            st.setString(3, campoCif.getText());
            st.setString(4, campoDireccion.getText());
            st.setString(5, campoCp.getText());
            st.setString(6, campoLocalidad.getText());
            st.setString(7, (String) campoJornada.getValue());
            st.setString(8, campoDniRes.getText());
            st.setString(9, campoNomRes.getText());
            st.setString(10, campoApellRes.getText());
            st.setString(11, campoDniTutor.getText());
            st.setString(12, campoNomTutor.getText());
            st.setString(13, campoApellTutor.getText());
            st.setString(14, campoMailTutor.getText());
            st.setString(15, campoTelTutor.getText());

            filas = st.executeUpdate();
            if (filas == 1) {
                filas = 0;
            } else {
                System.out.println("Ha habido un error en la inserción...");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        construyeTabla();
        construyeComboAlum();
        construyeComboEm();
        construyeComboTutor();
    }

    @FXML
    private void modificarEmpresa(ActionEvent event) {
        int filas = 0;
        try {
            st = conexion.prepareStatement("UPDATE empresas SET razonSocial=?, cif=?, direccion=?, cp=?, localidad=?, tipoJornada=?, dniResponsable=?, nombreResponsable=?, apellidosResponsable=?, dniTutorLaboral=?, nombreTutorLaboral=?, apellidosTutorLaboral=?, mailTutorLaboral=?, telefonoTutorLaboral=? WHERE codigoEmpresa=?");
            st.setInt(15, Integer.parseInt(campoCodEm.getText()));
            st.setString(1,campoNomEm.getText());
            st.setString(2, campoCif.getText());
            st.setString(3, campoDireccion.getText());
            st.setString(4, campoCp.getText());
            st.setString(5, campoLocalidad.getText());
            st.setString(6, (String) campoJornada.getValue());
            st.setString(7, campoDniRes.getText());
            st.setString(8, campoNomRes.getText());
            st.setString(9, campoApellRes.getText());
            st.setString(10, campoDniTutor.getText());
            st.setString(11, campoNomTutor.getText());
            st.setString(12, campoApellTutor.getText());
            st.setString(13, campoMailTutor.getText());
            st.setString(14, campoTelTutor.getText());

            filas = st.executeUpdate();
            if (filas == 1) {
                filas = 0;
            } else {
                System.out.println("Ha habido un error en la inserción...");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        construyeTabla();
        construyeComboAlum();
        construyeComboEm();
        construyeComboTutor();
    }
    
    @FXML
    private void consultarEmpresa(ActionEvent event) {      
        int valCod = Integer.parseInt(campoCodEm.getText());
        ResultSet resul = null;
        try {
            st = conexion.prepareStatement("SELECT * FROM empresas WHERE codigoEmpresa = ?");
            st.setInt(1, valCod);
            resul = st.executeQuery();
            while (resul.next()) {
                campoCodEm.setText(String.valueOf(resul.getInt("codigoEmpresa")));
                campoNomEm.setText(resul.getString("razonSocial"));
                campoCif.setText(resul.getString("cif"));
                campoDireccion.setText(resul.getString("direccion"));
                campoCp.setText(resul.getString("cp"));
                campoLocalidad.setText(resul.getString("localidad"));
                if (resul.getString("tipoJornada").equals("partida")) {
                    campoJornada.setValue("partida");
                } else {
                    campoJornada.setValue("continua");
                }
                campoDniRes.setText(resul.getString("dniResponsable"));
                campoNomRes.setText(resul.getString("nombreResponsable"));
                campoApellRes.setText(resul.getString("apellidosResponsable"));
                campoDniTutor.setText(resul.getString("dniTutorLaboral"));
                campoNomTutor.setText(resul.getString("nombreTutorLaboral"));
                campoApellTutor.setText(resul.getString("apellidosTutorLaboral"));
                campoMailTutor.setText(resul.getString("mailTutorLaboral"));
                campoTelTutor.setText(resul.getString("telefonoTutorLaboral"));
            }
        }catch(SQLException we) {
            we.printStackTrace();
        }
    }

    @FXML
    private void borrarEmpresa(ActionEvent event) {
        int filas = 0;
        try {
            st = conexion.prepareStatement("DELETE FROM empresas WHERE codigoEmpresa=?");
            st.setInt(1, Integer.parseInt(campoCodEm.getText()));
            filas = st.executeUpdate();
            if (filas == 1) {
                filas = 0;
            } else {
                System.out.println("Ha habido un error en la eliminación...");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        construyeTabla();
        construyeComboAlum();
        construyeComboEm();
        construyeComboTutor();
    }

    private String extraerNomRes(int codEm) {
        ResultSet rs = null;
        String nombreRes = null;
        try {
            st = conexion.prepareStatement("SELECT nombreResponsable, apellidosResponsable FROM empresas WHERE codigoEmpresa = ?");
            st.setInt(1, codEm);
            rs = st.executeQuery();
            while(rs.next()) {
                nombreRes = rs.getString("nombreResponsable") + " " + rs.getString("apellidosResponsable");
            }
        } catch(SQLException er){
            er.printStackTrace();
        }
        return nombreRes;
    }
    @FXML
    private void asignarAlumnos(ActionEvent event) {
        String valorAlum = (String) campoEleccionAlum.getValue();
        String valorEm = (String) campoEleccionEm.getValue();
        String valorTutor = (String) campoEleccionTutor.getValue();
        int codAlum = Integer.parseInt(valorAlum.split("-")[0]);
        int codEm = Integer.parseInt(valorEm.split("-")[0]);
        int codTutor = Integer.parseInt(valorTutor.split("-")[0]);
        String nomRes = extraerNomRes(codEm);
        String mensaje = "El alumno " + valorAlum + ", queda asignado a la empresa " + valorEm + " supervisados por los tutores " + valorTutor + " (docente) y " + nomRes + " (laboral).";
        campoMensaje.setText(mensaje);
        int filas = 0;
        try {
            st = conexion.prepareStatement("INSERT INTO asignados VALUES (?,?,?,?)");
            st.setInt(1, codEm);
            st.setInt(2, codAlum);
            st.setInt(3, codTutor);
            st.setString(4, mensaje);

            filas = st.executeUpdate();
            if (filas == 1) {
                filas = 0;
            } else {
                System.out.println("Ha habido un error en la inserción...");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void vinculoXML() {
        try {

            File fXML = new File("resources/tutoresSAFA.xml");

            DocumentBuilderFactory factoriaFich = DocumentBuilderFactory.newInstance();
            DocumentBuilder constructDoc = factoriaFich.newDocumentBuilder();
            Document fich = constructDoc.parse(fXML);

            NodeList listTutor = fich.getElementsByTagName("tutordoc");
            Node tutor = null;
            Element elemento = null;

            st = conexion.prepareStatement("INSERT INTO tutores VALUES (?,?,?,?,?)");

            String[] nomap = null;
            String nombre = null;
            int filas = 0;

            for (int i = 0; i < listTutor.getLength(); i++) {
                tutor = listTutor.item(i);
                if (tutor.getNodeType() == Node.ELEMENT_NODE) {
                    elemento = (Element) tutor;
                    st.setInt(1, Integer.parseInt(elemento.getElementsByTagName("codtut").item(0).getTextContent()));
                    nomap = elemento.getElementsByTagName("nomap").item(0).getTextContent().split(" ");
                    for (int j = 0; j < nomap.length - 1; j++) {
                        if (j == 0) {
                            nombre = nomap[j];
                        } else {
                            nombre = nombre + " " + nomap[j];
                        }
                    }
                    st.setString(2, nombre);
                    st.setString(3, nomap[nomap.length - 1]);
                    st.setString(4, elemento.getElementsByTagName("correo").item(0).getTextContent());
                    st.setString(5, elemento.getElementsByTagName("telefono").item(0).getTextContent());
                    filas = st.executeUpdate();

                    if (filas == 1) {
                        filas = 0;
                        continue;
                    } else {
                        System.out.println("Ha habido un error en la inserción...");
                        break;
                    }
                }
            }

            st.close();
        } catch (ParserConfigurationException | SAXException | IOException | SQLException e) {
            System.out.println("Error!");
        }
    }

    public void vinculoDAT() {

        File fichero = null;
        FileInputStream enStream = null;
        DataInputStream entrada = null;
        int filas = 0;
        try {
            fichero = new File("resources/alumnos2CFS.dat");
            enStream = new FileInputStream(fichero);
            entrada = new DataInputStream(enStream);
            st = conexion.prepareStatement("INSERT INTO alumnos VALUES (?,?,?,?,?)");
            while (true) {
                st.setString(1, String.valueOf(entrada.readInt()));
                st.setString(2, entrada.readUTF());
                st.setString(3, entrada.readUTF());
                st.setString(4, entrada.readUTF());
                st.setString(5, entrada.readUTF());

                filas = st.executeUpdate();
                if (filas == 1) {
                    filas = 0;
                    continue;
                } else {
                    System.out.println("Ha habido un error en la inserción...");
                    break;
                }
            }
        } catch (EOFException | FileNotFoundException | SQLException e) {
            e.printStackTrace();
        } catch (IOException w) {
            w.printStackTrace();
        }
    }
    
    @FXML
    private void vincularFicheros(ActionEvent event) {
        vinculoXML();
        vinculoDAT();
        construyeComboAlum();
        construyeComboEm();
        construyeComboTutor();
    }
}