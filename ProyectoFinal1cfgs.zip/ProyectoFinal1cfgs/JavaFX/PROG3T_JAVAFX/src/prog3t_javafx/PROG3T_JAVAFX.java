/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog3t_javafx;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 *
 * @author Usuario
 */
public class PROG3T_JAVAFX extends Application {
    
    Connection conexion = null;
    PreparedStatement st = null;
    
    private ObservableList<ObservableList> data;
    private TableView tableview;
    
    public void buildData() {
        data = FXCollections.observableArrayList();
        ResultSet rs = null;
        try{
            try {
                st = conexion.prepareStatement("SELECT codigoEmpresa, razonSocial, nombreResponsable, nombreTutorLaboral FROM empresas");
                rs = st.executeQuery();
            }catch(SQLException n) {
                n.printStackTrace();
            }

        }catch(Exception e){
            e.printStackTrace();
            System.out.println("Error on Building Data");             
        }
    }
    
            
    @Override
    public void start(Stage stage) throws Exception {
        try {
            Class.forName("org.mariadb.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mariadb://localhost:3306/proy3te4", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
   
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
