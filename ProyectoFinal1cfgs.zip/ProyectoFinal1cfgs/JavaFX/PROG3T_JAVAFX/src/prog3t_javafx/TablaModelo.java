/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog3t_javafx;

import javafx.fxml.Initializable;
/**
 *
 * @author Usuario
 */
public class TablaModelo {
    public String codigoEmpresa = null;
    public String nombreEmpresa = null;
    public String nombreResponsable = null;
    public String nombreTutor = null;
    
    public TablaModelo(int codEm, String nomEm, String nomRes, String nomTutor) {
        this.codigoEmpresa = String.valueOf(codEm);
        this.nombreEmpresa = nomEm;
        this.nombreResponsable = nomRes;
        this.nombreTutor = nomTutor;
    }
    
    public String getCodigoEmpresa() {
        return this.codigoEmpresa;
    }
    
    public String getNombreEmpresa() {
        return this.nombreEmpresa;
    }
    
    public String getNombreResponsable() {
        return this.nombreResponsable;
    }
    
    public String getNombreTutor() {
        return this.nombreTutor;
    }
}
