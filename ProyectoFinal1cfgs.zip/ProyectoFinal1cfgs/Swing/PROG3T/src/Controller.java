import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.swing.table.DefaultTableModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.sql.*;
import java.util.Vector;

public class Controller {
    Connection conexion = null;
    PreparedStatement st = null;

    public Controller() {
        try {
            Class.forName("org.mariadb.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mariadb://localhost:3306/proy3te4", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
    public void vinculoXML() {
        try {

            File fXML = new File("../resources/tutoresSAFA.xml");

            DocumentBuilderFactory factoriaFich = DocumentBuilderFactory.newInstance();
            DocumentBuilder constructDoc = factoriaFich.newDocumentBuilder();
            Document fich = constructDoc.parse(fXML);

            NodeList listTutor = fich.getElementsByTagName("tutordoc");
            Node tutor = null;
            Element elemento = null;

            st = conexion.prepareStatement("INSERT INTO tutores VALUES (?,?,?,?,?)");

            String[] nomap = null;
            String nombre = null;
            int filas = 0;

            for (int i = 0; i < listTutor.getLength(); i++) {
                tutor = listTutor.item(i);
                if (tutor.getNodeType() == Node.ELEMENT_NODE) {
                    elemento = (Element) tutor;
                    st.setInt(1, Integer.parseInt(elemento.getElementsByTagName("codtut").item(0).getTextContent()));
                    nomap = elemento.getElementsByTagName("nomap").item(0).getTextContent().split(" ");
                    for (int j = 0; j < nomap.length - 1; j++) {
                        if (j == 0) {
                            nombre = nomap[j];
                        } else {
                            nombre = nombre + " " + nomap[j];
                        }
                    }
                    st.setString(2, nombre);
                    st.setString(3, nomap[nomap.length - 1]);
                    st.setString(4, elemento.getElementsByTagName("correo").item(0).getTextContent());
                    st.setString(5, elemento.getElementsByTagName("telefono").item(0).getTextContent());
                    filas = st.executeUpdate();

                    if (filas == 1) {
                        filas = 0;
                        continue;
                    } else {
                        System.out.println("Ha habido un error en la inserción...");
                        break;
                    }
                }
            }

            st.close();
        } catch (ParserConfigurationException | SAXException | IOException | SQLException e) {
            System.out.println("Error!");
        }
    }

    public void vinculoDAT() {

        File fichero = null;
        FileInputStream enStream = null;
        DataInputStream entrada = null;
        int filas = 0;
        try {
            fichero = new File("../resources/alumnos2CFS.dat");
            enStream = new FileInputStream(fichero);
            entrada = new DataInputStream(enStream);
            st = conexion.prepareStatement("INSERT INTO alumnos VALUES (?,?,?,?,?)");
            while (true) {
                st.setString(1, String.valueOf(entrada.readInt()));
                st.setString(2, entrada.readUTF());
                st.setString(3, entrada.readUTF());
                st.setString(4, entrada.readUTF());
                st.setString(5, entrada.readUTF());

                filas = st.executeUpdate();
                if (filas == 1) {
                    filas = 0;
                    continue;
                } else {
                    System.out.println("Ha habido un error en la inserción...");
                    break;
                }
            }
        } catch (EOFException | FileNotFoundException | SQLException e) {
            e.printStackTrace();
        } catch (IOException w) {
            w.printStackTrace();
        }
    }

    public void insercionEmpresa(int valCod, String valRazon, String valCif,  String valDireccion, String valCp, String valLocalidad, String valJornada, String valDniRes, String valNomRes, String valApellRes, String valDniTutor, String valNomTutor, String valApellTutor, String valMailTutor, String valTelefTutor) {

        int filas = 0;
        try {
            st = conexion.prepareStatement("INSERT INTO empresas VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            st.setInt(1, valCod);
            st.setString(2, valRazon);
            st.setString(3, valCif);
            st.setString(4, valDireccion);
            st.setString(5, valCp);
            st.setString(6, valLocalidad);
            st.setString(7, valJornada);
            st.setString(8, valDniRes);
            st.setString(9, valNomRes);
            st.setString(10, valApellRes);
            st.setString(11, valDniTutor);
            st.setString(12, valNomTutor);
            st.setString(13, valApellTutor);
            st.setString(14, valMailTutor);
            st.setString(15, valTelefTutor);

            filas = st.executeUpdate();
            if (filas == 1) {
                filas = 0;
            } else {
                System.out.println("Ha habido un error en la inserción...");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void modificacionEmpresa(int valCod, String valRazon, String valCif,  String valDireccion, String valCp, String valLocalidad, String valJornada, String valDniRes, String valNomRes, String valApellRes, String valDniTutor, String valNomTutor, String valApellTutor, String valMailTutor, String valTelefTutor) {

        int filas = 0;
        try {
            st = conexion.prepareStatement("UPDATE empresas SET razonSocial=?, cif=?, direccion=?, cp=?, localidad=?, tipoJornada=?, dniResponsable=?, nombreResponsable=?, apellidosResponsable=?, dniTutorLaboral=?, nombreTutorLaboral=?, apellidosTutorLaboral=?, mailTutorLaboral=?, telefonoTutorLaboral=? WHERE codigoEmpresa=?");
            st.setInt(15, valCod);
            st.setString(1, valRazon);
            st.setString(2, valCif);
            st.setString(3, valDireccion);
            st.setString(4, valCp);
            st.setString(5, valLocalidad);
            st.setString(6, valJornada);
            st.setString(7, valDniRes);
            st.setString(8, valNomRes);
            st.setString(9, valApellRes);
            st.setString(10, valDniTutor);
            st.setString(11, valNomTutor);
            st.setString(12, valApellTutor);
            st.setString(13, valMailTutor);
            st.setString(14, valTelefTutor);

            filas = st.executeUpdate();
            if (filas == 1) {
                filas = 0;
            } else {
                System.out.println("Ha habido un error en la modificación...");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public ResultSet consultarEmpresa(int valCod) {
        ResultSet rs = null;
        try {
            st = conexion.prepareStatement("SELECT * FROM empresas WHERE codigoEmpresa = ?");
            st.setInt(1, valCod);
            rs = st.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs;
    }

    public void eliminacionEmpresa(int valCod) {
        int filas = 0;
        try {
            st = conexion.prepareStatement("DELETE FROM empresas WHERE codigoEmpresa=?");
            st.setInt(1, valCod);
            filas = st.executeUpdate();
            if (filas == 1) {
                filas = 0;
            } else {
                System.out.println("Ha habido un error en la eliminación...");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public ResultSet recogeDatosEmpresas() {
        ResultSet rs = null;
        try {
            st = conexion.prepareStatement("SELECT codigoEmpresa, razonSocial, nombreResponsable, nombreTutorLaboral FROM empresas");
            rs = st.executeQuery();

        }catch(SQLException e){
            e.printStackTrace();
        }
        return rs;
    }
    public DefaultTableModel construyeTabla() {
        ResultSet resul = null;
        Vector<String> nombreColumnas = null;
        Vector<Vector<Object>> datos = null;
        try {
            resul = recogeDatosEmpresas();
            ResultSetMetaData rsMd = resul.getMetaData();
            nombreColumnas = new Vector<String>();
            int numColumnas = rsMd.getColumnCount();
            for (int i= 1; i<=numColumnas; i++) {
                nombreColumnas.add(rsMd.getColumnName(i));
            }
            datos = new Vector<Vector<Object>>();
            while (resul.next()) {
                Vector<Object> vector = new Vector<Object>();
                for (int j = 1; j<=numColumnas; j++) {
                    vector.add(resul.getObject(j));
                }
                datos.add(vector);
            }
        }catch(SQLException e) {
            e.printStackTrace();
        }
        return new DefaultTableModel(datos, nombreColumnas);
    }
    public ResultSet rellenarComboboxAlum() {
        ResultSet rs = null;
        try {
            st = conexion.prepareStatement("SELECT codigoAlumno, nombre, apellidos FROM alumnos");
            rs = st.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs;
    }
    public ResultSet rellenarComboboxEm() {
        ResultSet rs = null;
        try {
            st = conexion.prepareStatement("SELECT codigoEmpresa, razonSocial FROM empresas");
            rs = st.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs;
    }
    public ResultSet rellenarComboboxProf() {
        ResultSet rs = null;
        try {
            st = conexion.prepareStatement("SELECT codigoTutor, nombre, apellidos FROM tutores");
            rs = st.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return rs;
    }
    public String extraerNomRes(int codEm) {
        ResultSet rs = null;
        String nombreRes = null;
        try {
            st = conexion.prepareStatement("SELECT nombreResponsable, apellidosResponsable FROM empresas WHERE codigoEmpresa = ?");
            st.setInt(1, codEm);
            rs = st.executeQuery();
            while(rs.next()) {
                nombreRes = rs.getString("nombreResponsable") + " " + rs.getString("apellidosResponsable");
            }
        } catch(SQLException er){
            er.printStackTrace();
        }
        return nombreRes;
    }
    public void insertarAsignacion(int codEm, int codAlum, int codTutor, String mensaje) {
        int filas = 0;
        try {
            st = conexion.prepareStatement("INSERT INTO asignados VALUES (?,?,?,?)");
            st.setInt(1, codEm);
            st.setInt(2, codAlum);
            st.setInt(3, codTutor);
            st.setString(4, mensaje);

            filas = st.executeUpdate();
            if (filas == 1) {
                filas = 0;
            } else {
                System.out.println("Ha habido un error en la inserción...");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
