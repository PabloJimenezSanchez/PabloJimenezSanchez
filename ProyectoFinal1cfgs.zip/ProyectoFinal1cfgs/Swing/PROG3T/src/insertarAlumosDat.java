import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class insertarAlumosDat {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        try {
            int codAlumno;
            String dni, nombreAlumno, apellidosAlumnos, fechaNac;

            FileOutputStream fichero = new FileOutputStream("resources/alumnos2CFS.dat", true);
            DataOutputStream fich = new DataOutputStream(fichero);

            System.out.println("\nInsertar alumno");
            System.out.print("\n\tCódigo del alumno: ");
            codAlumno = entrada.nextInt();
            fich.writeInt(codAlumno);

            System.out.print("\tDNI del alumno: ");
            dni = entrada.next();
            fich.writeUTF(dni);

            System.out.print("\tNombre del alumno: ");
            nombreAlumno = entrada.next();
            fich.writeUTF(nombreAlumno);

            System.out.print("\tApellidos del alumno: ");
            apellidosAlumnos = entrada.next();
            fich.writeUTF(apellidosAlumnos);

            System.out.print("\tFecha de nacimiento del alumno: ");
            fechaNac = entrada.next();
            fich.writeUTF(fechaNac);

            fichero.close();
            fich.close();
            System.out.println("\n\t\tDatos incorporados al fichero");
        }catch (IOException e) {
            System.out.println("\nError al crear el fichero...");
        }

    }

}
