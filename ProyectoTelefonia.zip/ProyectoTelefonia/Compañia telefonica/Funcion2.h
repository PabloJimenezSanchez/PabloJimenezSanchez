#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include <wchar.h>
#include <locale.h>
#include <time.h>
#ifndef _FUNCION2_H_
#define _FUNCION2_H_

void FCASO2(reg2, idmensaje);

#endif
