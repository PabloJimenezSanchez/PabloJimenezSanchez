#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include <wchar.h>
#include <locale.h>
#include <time.h>
#ifndef _FUNCION6_H_
#define _FUNCION6_H_

void FCASO7(reg2, idmensaje);

#endif
