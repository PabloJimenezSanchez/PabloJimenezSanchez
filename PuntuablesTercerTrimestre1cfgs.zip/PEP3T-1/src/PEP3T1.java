import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class PEP3T1 {

    public static void main(String[] args) {

        String texto1, texto2, texto3, texto4, texto5, texto6, textoMadre, textoMadre2="";

        Scanner entrada = new  Scanner(System.in);

        try {
            FileWriter fw = new FileWriter("src\\FicheroCambiaVocales.txt");

            System.out.println("\n\t\t\t\t\t\tPROGRAMA CAMBIAVOCALES\n\t\t\t\t\t\t----------------------");
            System.out.println("\n\nIntroduzca el texto: ");

            texto1 = entrada.nextLine();
            texto2 = entrada.nextLine();
            texto3 = entrada.nextLine();
            texto4 = entrada.nextLine();
            texto5 = entrada.nextLine();
            texto6 = entrada.nextLine();

            textoMadre = texto1+"\n"+texto2+"\n"+texto3+"\n"+texto4+"\n"+texto5+"\n"+texto6;

            if (texto1.length() > 80 || texto2.length() > 80 || texto3.length() > 80 || texto4.length() > 80 || texto5.length() > 80 || texto6.length() > 80) {
                System.out.println("\nEl texto es demasiado largo");
            }
            else {
                textoValido(textoMadre, textoMadre2, fw);
            }
        }
        catch (IOException e) {
            System.out.println("No se ha podido crear el fichero");
        }
    }

    public static void textoValido(String textoMadre, String textoMadre2, FileWriter fw) throws IOException {
        int I;
        char letra;
        System.out.println("\nEl texto es válido");

        fw.write(textoMadre);

        fw.flush();

        for (I = 0; I < textoMadre.length(); I++) {
            letra = textoMadre.charAt(I);

            if (letra == 'a') {
                letra = 'i';
            }
            if (letra == 'A') {
                letra = 'I';
            }
            if (letra == 'e') {
                letra = 'o';
            }
            if (letra == 'E') {
                letra = 'O';
            }

            textoMadre2 = textoMadre2 + letra;
        }

        System.out.println("\nEl texto almacenado, una vez procesado: \n" + textoMadre2);
    }
}
