import java.util.InputMismatchException;
import java.util.Scanner;

public class PEP3T_3 {

    public static void main(String[] args) {

        metodos llamada = new metodos();

        int opcion=0;

        do {
            System.out.println("\n\n\t\t\t\tFICHERO XML CON JAVA");
            System.out.println("\n\t\t\t\t\t\tMenú de Opciones");
            System.out.println("\t\t\t\t\t\t================");
            System.out.println("\n\t\t1) Presentar el documento XML completo");
            System.out.println("\t\t2) Añadir nuevo nodo al documento");
            System.out.println("\t\t3) Modificar datos de un nodo del documento");
            System.out.println("\t\t4) Eliminar un nodo concreto del documento");
            System.out.println("\t\t5) Salir");
            System.out.print("\n\t\t\t\t\t\tOpción: ");

            try {
                opcion = llamada.excepcion1();

                switch (opcion) {
                    case 1:
                        llamada.caso1();
                        break;
                    case 2:
                        llamada.caso2();
                        break;
                    case 3:
                        llamada.caso3();
                        break;
                    case 4:
                        llamada.caso4();
                        break;
                    case 5:
                        System.out.println("\nSaliendo del programa...");
                        break;
                    default:
                        System.out.println("\n\tDebes teclear una opción válida...");
                        break;
                }
            }catch (Exception e) {
                System.out.println("\n\tDebes teclear un número entero...");
            }
        }
        while (opcion != 5);
    }
}