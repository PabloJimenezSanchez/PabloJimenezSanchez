import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.Scanner;

public class metodos {

    public int excepcion1() {
        Scanner entrada = new Scanner(System.in);
        int opcion = entrada.nextInt();
        entrada.nextLine();
        return opcion;
    }

    public void caso1() {

        File fXML = new File("src//peliculas.xml");

        System.out.println("\n\nPresentación del documento XML\n");

        try {
            DocumentBuilderFactory factoriaFich = DocumentBuilderFactory.newInstance();
            DocumentBuilder constructDoc = factoriaFich.newDocumentBuilder();
            Document fich = constructDoc.parse(fXML);

            fich.getDocumentElement().normalize();

            Element raiz = fich.getDocumentElement();
            System.out.println(raiz.getNodeName());

            NodeList listPeli = fich.getElementsByTagName("pelicula");
            for (int i = 0; i < listPeli.getLength(); i++) {
                Node nodo = listPeli.item(i);
                System.out.println("\n" + nodo.getNodeName());

                if (nodo.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) nodo;
                    System.out.println("Título: " + element.getElementsByTagName("titulo").item(0).getTextContent());
                    System.out.println("Guionista: " + element.getElementsByTagName("guionista").item(0).getTextContent());
                    System.out.println("Productora: " + element.getElementsByTagName("productora").item(0).getTextContent());
                    System.out.println("Director: " + element.getElementsByTagName("director").item(0).getTextContent());
                    System.out.println("Actor: " + element.getElementsByTagName("actor").item(0).getTextContent());
                    System.out.println("Sinopsis: " + element.getElementsByTagName("sinopsis").item(0).getTextContent());
                }
            }

        } catch (Exception e) {
            System.out.println("Se produjo un error durante la ejecución...");
        }
    }

    public void caso2() {

        Scanner entrada = new Scanner(System.in);

        int opcion = 0;
        File fXML = new File("src//peliculas.xml");

        try {
            DocumentBuilderFactory factoriaFich = DocumentBuilderFactory.newInstance();
            DocumentBuilder constructDoc = factoriaFich.newDocumentBuilder();
            Document fich = constructDoc.parse(fXML);

            Element raiz = fich.getDocumentElement();
            Element pelicula = fich.createElement("pelicula");
            NodeList peliculas = raiz.getChildNodes();

            System.out.println("\n\t¿Dónde desea agregar la nueva película?");
            System.out.println("\t\t1) Al princpio del documento");
            System.out.println("\t\t2) En el intermedio");
            System.out.println("\t\t3) Al final del documento");
            System.out.print("\n\t\t\tOpción: ");

            try {
                opcion = excepcion1();

            switch (opcion) {
                case 1:
                    raiz.insertBefore(pelicula, raiz.getFirstChild());
                    crearPelicula(entrada, fXML, fich, pelicula);
                    break;
                case 2:
                    opcion = peliculas.getLength() / 2;
                    Node pel = peliculas.item(opcion);
                    pel.appendChild(pelicula);
                    crearPelicula(entrada, fXML, fich, pelicula);
                    break;
                case 3:
                    raiz.appendChild(pelicula);
                    crearPelicula(entrada, fXML, fich, pelicula);
                    break;
                default:
                    System.out.println("\n\tDebes teclear una opción válida...");
            }
            } catch (Exception e) {
                System.out.println("\n\tDebes teclear un número entero...");
            }
        } catch (Exception e) {
            System.out.println("Se produjo un error durante la ejecución...");
        }
    }

    public void caso3() {

        Scanner entrada = new Scanner(System.in);

        int opcion=0;

        File fXML = new File("src//peliculas.xml");

        System.out.println("\n\nModificación del documento XML");

        try {
            DocumentBuilderFactory factoriaFich = DocumentBuilderFactory.newInstance();
            DocumentBuilder constructDoc = factoriaFich.newDocumentBuilder();
            Document fich = constructDoc.parse(fXML);

            fich.getDocumentElement().normalize();

            Node raiz = fich.getFirstChild();
            NodeList listaPeliculas = raiz.getChildNodes();


            System.out.println("\n\t¿Dónde desea modificar el documento XML?");
            System.out.println("\t\t1) Al princpio del documento");
            System.out.println("\t\t2) En el intermedio");
            System.out.println("\t\t3) Al final del documento");
            System.out.print("\n\t\t\tOpción: ");

            try {
                opcion = excepcion1();

            switch (opcion) {
                case 1:
                    opcion = 0;
                    modPelicula(entrada, opcion, fXML, fich);
                    break;
                case 2:
                    opcion = listaPeliculas.getLength() / 2;
                    modPelicula(entrada, opcion, fXML, fich);
                    break;
                case 3:
                    opcion = listaPeliculas.getLength();
                    modPelicula(entrada, opcion, fXML, fich);
                    break;
                default:
                    System.out.println("\n\tDebes teclear una opción válida...");
                    break;
            }
            } catch (Exception e) {
                System.out.println("\n\tDebes teclear un número entero...");
            }
        } catch (Exception e) {
            System.out.println("Se produjo un error durante la ejecución...");
        }
    }


    public void caso4() {
        
        int opcion=0;
        File fXML = new File("src//peliculas.xml");

        System.out.println("\n\nEliminación de algún nodo del documento XML");

        try {
            DocumentBuilderFactory factoriaFich = DocumentBuilderFactory.newInstance();
            DocumentBuilder constructDoc = factoriaFich.newDocumentBuilder();
            Document fich = constructDoc.parse(fXML);

            fich.getDocumentElement().normalize();

            Node raiz = fich.getFirstChild();
            NodeList listaPeliculas = raiz.getChildNodes();

            System.out.println("\n\t¿Dónde desea eliminar el nodo?");
            System.out.println("\t\t1) Al princpio del documento");
            System.out.println("\t\t2) En el intermedio");
            System.out.println("\t\t3) Al final del documento");
            System.out.print("\n\t\t\tOpción: ");

            try {
                opcion = excepcion1();

            switch (opcion) {
                case 1:
                    opcion = 0;
                    elimPelicula(opcion, fXML, fich);
                    break;
                case 2:
                    opcion = listaPeliculas.getLength()/2;
                    elimPelicula(opcion, fXML, fich);
                    break;
                case 3:
                    opcion = listaPeliculas.getLength()-1;
                    elimPelicula(opcion, fXML, fich);
                    break;
                default:
                    System.out.println("\n\tDebes teclear una opción válida...");
                    break;
            }
            } catch (Exception e) {
                System.out.println("\n\tDebes teclear un número entero...");
            }
        } catch (Exception e) {
            System.out.println("Se produjo un error durante la ejecución...");
        }
    }



    //##################################################################################################################

    public void crearPelicula(Scanner entrada, File fXML, Document fich, Element pelicula) throws TransformerException {

        String enTitulo, enGuionista, enProductora, enDirector, enActor, enSinopsis;

        Element titulo = fich.createElement("titulo");
        System.out.print("\n\tIntroduzca el título de la pelicula: ");
        enTitulo = entrada.nextLine();
        titulo.appendChild(fich.createTextNode(enTitulo));
        pelicula.appendChild(titulo);

        Element guionista = fich.createElement("guionista");
        System.out.print("\tIntroduzca el nombre del guionista: ");
        enGuionista = entrada.nextLine();
        guionista.appendChild(fich.createTextNode(enGuionista));
        pelicula.appendChild(guionista);

        Element productora = fich.createElement("productora");
        System.out.print("\tIntroduzca el nombre de la productora: ");
        enProductora = entrada.nextLine();
        productora.appendChild(fich.createTextNode(enProductora));
        pelicula.appendChild(productora);

        Element director = fich.createElement("director");
        System.out.print("\tIntroduzca el nombre del director: ");
        enDirector = entrada.nextLine();
        director.appendChild(fich.createTextNode(enDirector));
        pelicula.appendChild(director);

        Element actor = fich.createElement("actor");
        System.out.print("\tIntroduzca el nombre del actor: ");
        enActor = entrada.nextLine();
        actor.appendChild(fich.createTextNode(enActor));
        pelicula.appendChild(actor);

        Element sinopsis = fich.createElement("sinopsis");
        System.out.print("\tIntroduzca la sinopsis: ");
        enSinopsis = entrada.nextLine();
        sinopsis.appendChild(fich.createTextNode(enSinopsis));
        pelicula.appendChild(sinopsis);

        TransformerFactory factoriaTransf = TransformerFactory.newInstance();
        Transformer transfor = factoriaTransf.newTransformer();
        DOMSource fuenteDom = new DOMSource(fich);

        StreamResult resultado = new StreamResult(fXML);
        transfor.transform(fuenteDom, resultado);
        System.out.println("\n\t\tSe ha añadido un nuevo elemento al XML...");
    }

    public void modPelicula(Scanner entrada, int opcion, File fXML, Document fich) throws TransformerException {

        String enTitulo, enGuionista, enProductora, enDirector, enActor, enSinopsis;

        Node peliculaMod = fich.getElementsByTagName("pelicula").item(opcion);
        NodeList listPeli = peliculaMod.getChildNodes();

        for (int i = 0; i < listPeli.getLength(); i++) {
            Node nodo = listPeli.item(i);
            if ("titulo".equals(nodo.getNodeName())) {
                System.out.print("\n\tIntroduzca el nuevo título: ");
                enTitulo = entrada.nextLine();
                nodo.setTextContent(enTitulo);
            }
            if ("guionista".equals(nodo.getNodeName())) {
                System.out.print("\tIntroduzca el nuevo guionista: ");
                enGuionista = entrada.nextLine();
                nodo.setTextContent(enGuionista);
            }
            if ("productora".equals(nodo.getNodeName())) {
                System.out.print("\tIntroduzca la nueva productora: ");
                enProductora = entrada.nextLine();
                nodo.setTextContent(enProductora);
            }
            if ("director".equals(nodo.getNodeName())) {
                System.out.print("\tIntroduzca el nuevo director: ");
                enDirector = entrada.nextLine();
                nodo.setTextContent(enDirector);
            }
            if ("actor".equals(nodo.getNodeName())) {
                System.out.print("\tIntroduzca el nuevo actor: ");
                enActor = entrada.nextLine();
                nodo.setTextContent(enActor);
            }
            if ("sinopsis".equals(nodo.getNodeName())) {
                System.out.print("\tIntroduzca la nueva sinopsis: ");
                enSinopsis = entrada.nextLine();
                nodo.setTextContent(enSinopsis);
            }
        }

        System.out.println("\n\t\tSe ha modifcado la película correspondiente al nodo "+opcion);

        TransformerFactory factoriaTransf = TransformerFactory.newInstance();
        Transformer transfor = factoriaTransf.newTransformer();
        DOMSource fuenteDom = new DOMSource(fich);

        StreamResult resultado = new StreamResult(fXML);
        transfor.transform(fuenteDom, resultado);
    }

    public void elimPelicula(int opcion, File fXML, Document fich) throws TransformerException {
        Node peliculaElim = fich.getElementsByTagName("pelicula").item(opcion);
        peliculaElim.getParentNode().removeChild(peliculaElim);

        System.out.println("\n\t\tSe ha eliminado la película correspondiente al nodo "+opcion);

        TransformerFactory factoriaTransf = TransformerFactory.newInstance();
        Transformer transfor = factoriaTransf.newTransformer();
        DOMSource fuenteDom = new DOMSource(fich);

        StreamResult resultado = new StreamResult(fXML);
        transfor.transform(fuenteDom, resultado);
    }
}