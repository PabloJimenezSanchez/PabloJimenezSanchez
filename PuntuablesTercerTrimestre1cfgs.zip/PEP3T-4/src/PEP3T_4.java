import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class PEP3T_4 {

    private static final String ADD_DRIVER = "org.mariadb.jdbc.Driver";
    private static final String URL_CONEXION = "jdbc:mariadb://localhost:3306/PUNTU4";

    public static void main(String[] args) {

        JFrame ventana;
        JPanel panelTitulo, panelCodigo, panelNombre, panelNotas, panelBotones, panelInfo;
        JLabel titulo, codMatricula, nomAsignatura, nota1, nota2, info;
        JTextField textoCodMatricula, textoNomAsignatura, textoNota1, textoNota2;
        JButton insertar, modificar, borrar, consultar;

        ventana = new JFrame("Ejercicio PEP3T-4 JAVA");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(400, 300);
        ventana.setLayout(new FlowLayout(FlowLayout.LEFT, 10, 7));
        ventana.setResizable(true);


        panelTitulo = new JPanel(new FlowLayout());
        panelTitulo.setBorder(BorderFactory.createEmptyBorder(5, 80, 5, 100));
        panelTitulo.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        ventana.add(panelTitulo);

        panelCodigo = new JPanel(new FlowLayout());
        panelCodigo.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 100));
        panelCodigo.setLayout(new FlowLayout(FlowLayout.LEFT, 8, 0));
        ventana.add(panelCodigo);

        panelNombre = new JPanel(new FlowLayout());
        panelNombre.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 100));
        panelNombre.setLayout(new FlowLayout(FlowLayout.LEFT, 8, 0));
        ventana.add(panelNombre);

        panelNotas = new JPanel(new FlowLayout());
        panelNotas.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 100));
        panelNotas.setLayout(new FlowLayout(FlowLayout.LEFT, 8, 0));
        ventana.add(panelNotas);

        panelBotones = new JPanel(new FlowLayout());
        panelBotones.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 100));
        panelBotones.setLayout(new FlowLayout(FlowLayout.LEFT, 8, 8));
        ventana.add(panelBotones);

        panelInfo = new JPanel(new FlowLayout());
        panelInfo.setBorder(BorderFactory.createEmptyBorder(5, 100, 5, 100));
        panelInfo.setLayout(new FlowLayout(FlowLayout.LEFT, 8, 8));
        ventana.add(panelInfo);

        titulo = new JLabel("GESTIÓN DE LA TABLA NOTAS");
        panelTitulo.add(titulo);

        codMatricula = new JLabel("Código Matrícula:");
        panelCodigo.add(codMatricula);

        textoCodMatricula = new JTextField(7);
        panelCodigo.add(textoCodMatricula);

        nomAsignatura = new JLabel("Nombre Asignatura");
        panelNombre.add(nomAsignatura);

        textoNomAsignatura = new JTextField(15);
        panelNombre.add(textoNomAsignatura);

        nota1 = new JLabel("Nota 1:");
        panelNotas.add(nota1);

        textoNota1 = new JTextField(5);
        panelNotas.add(textoNota1);

        nota2 = new JLabel("Nota 2:");
        panelNotas.add(nota2);

        textoNota2 = new JTextField(5);
        panelNotas.add(textoNota2);

        insertar = new JButton("Insertar");
        panelBotones.add(insertar);

        modificar = new JButton("Modificar");
        panelBotones.add(modificar);

        borrar = new JButton("Borrar");
        panelBotones.add(borrar);

        consultar = new JButton("Consultar");
        panelBotones.add(consultar);

        info = new JLabel();
        panelInfo.add(info);

        ventana.setVisible(true);

        insertar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String cod_matricula, nom_asignatura, fnota1, fnota2;
                try {

                    cod_matricula = textoCodMatricula.getText();
                    nom_asignatura = textoNomAsignatura.getText();
                    fnota1 = textoNota1.getText();
                    fnota2 = textoNota2.getText();

                    Class.forName(ADD_DRIVER);
                    Connection conexionBase = DriverManager.getConnection(URL_CONEXION, "root", "");
                    PreparedStatement encapConst = conexionBase.prepareStatement("INSERT INTO notas VALUES (?,?,?,?)");

                    encapConst.setString(1, cod_matricula);
                    encapConst.setString(2, nom_asignatura);
                    encapConst.setString(3, fnota1);
                    encapConst.setString(4, fnota2);

                    encapConst.executeUpdate();
                    encapConst.close();
                    conexionBase.close();

                    info.setText("Registro insertado...");
                    textoCodMatricula.setText("");
                    textoNomAsignatura.setText("");
                    textoNota1.setText("");
                    textoNota2.setText("");

                } catch (ClassNotFoundException | SQLException w) {
                    System.out.println("Hubo un problema durante la ejecución del programa...");
                }
            }
        });

        modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String cod_matricula, nom_asignatura, fnota1, fnota2;
                try {

                    cod_matricula = textoCodMatricula.getText();
                    nom_asignatura = textoNomAsignatura.getText();
                    fnota1 = textoNota1.getText();
                    fnota2 = textoNota2.getText();

                    Class.forName(ADD_DRIVER);
                    Connection conexionBase = DriverManager.getConnection(URL_CONEXION, "root", "");
                    PreparedStatement encapConst = conexionBase.prepareStatement("UPDATE notas SET cod_matricula=?, nom_asignatura=?, nota1=?, nota2=?"+"WHERE cod_matricula=?");

                    encapConst.setString(1, cod_matricula);
                    encapConst.setString(2, nom_asignatura);
                    encapConst.setString(3, fnota1);
                    encapConst.setString(4, fnota2);
                    encapConst.setString(5, cod_matricula);

                    encapConst.executeUpdate();
                    encapConst.close();
                    conexionBase.close();

                    info.setText("Registro modificado...");
                    textoCodMatricula.setText("");
                    textoNomAsignatura.setText("");
                    textoNota1.setText("");
                    textoNota2.setText("");

                } catch (ClassNotFoundException | SQLException w) {
                    System.out.println("Hubo un problema durante la ejecución del programa...");
                }
            }
        });

        borrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String cod_matricula;
                try {

                    cod_matricula = textoCodMatricula.getText();

                    Class.forName(ADD_DRIVER);
                    Connection conexionBase = DriverManager.getConnection(URL_CONEXION, "root", "");
                    PreparedStatement encapConst = conexionBase.prepareStatement("DELETE FROM notas WHERE cod_matricula=?");

                    encapConst.setString(1, cod_matricula);

                    encapConst.executeUpdate();
                    encapConst.close();
                    conexionBase.close();

                    info.setText("Registro eliminado...");
                    textoCodMatricula.setText("");
                    textoNomAsignatura.setText("");
                    textoNota1.setText("");
                    textoNota2.setText("");

                } catch (ClassNotFoundException | SQLException w) {
                    System.out.println("Hubo un problema durante la ejecución del programa...");
                }
            }
        });

        consultar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String cod_matricula, nom_asignatura="", fnota1="", fnota2="";
                try {

                    cod_matricula = textoCodMatricula.getText();

                    Class.forName(ADD_DRIVER);
                    Connection conexionBase = DriverManager.getConnection(URL_CONEXION, "root", "");
                    PreparedStatement encapConst = conexionBase.prepareStatement("SELECT * FROM notas WHERE cod_matricula=?");
                    encapConst.setString(1, cod_matricula);

                    ResultSet rs = encapConst.executeQuery();

                    while (rs.next()) {
                        nom_asignatura = rs.getString("nom_asignatura");
                        fnota1 = rs.getString("nota1");
                        fnota2 = rs.getString("nota2");
                        textoNomAsignatura.setText(nom_asignatura);
                        textoNota1.setText(fnota1);
                        textoNota2.setText(fnota2);
                    }

                    encapConst.close();
                    conexionBase.close();

                    info.setText("Registro encontrado...");

                } catch (Exception w) {
                    System.out.println(w.getMessage());
                }
            }
        });
    }
}