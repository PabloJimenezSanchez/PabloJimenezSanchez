import java.util.InputMismatchException;

public class PEP3T2 {

    public static void main(String[] args) {

        metodos llamada = new metodos();

        int opcion=0;

        do {
            System.out.println("\n\n\t\t\t\tPROGRAMA GESTIÓN COMPAÑÍA TELEFÓNICA");
            System.out.println("\n\t\t\t\t\t\tMenú de Opciones");
            System.out.println("\t\t\t\t\t\t================");
            System.out.println("\n\t\t1) Alta de nuevas facturas");
            System.out.println("\t\t2) Modificación del valor de factura");
            System.out.println("\t\t3) Consulta del dato de facturación de un abonado");
            System.out.println("\t\t4) Consulta del dato de facturación total de la compañía");
            System.out.println("\t\t5) Eliminar el fichero");
            System.out.println("\t\t6) Salir");
            System.out.print("\n\t\t\t\t\t\tOpción: ");

            try {
                opcion = llamada.excepcion1();

                switch (opcion) {
                    case 1:
                        llamada.caso1();
                        break;
                    case 2:
                        llamada.caso2();
                        break;
                    case 3:
                        llamada.caso3();
                        break;
                    case 4:
                        llamada.caso4();
                        break;
                    case 5:
                        llamada.caso5();
                        break;
                    case 6:
                        System.out.println("\nSaliendo del programa...");
                        break;
                    default:
                        System.out.println("\n\tDebes teclear una opción válida...");
                        break;
                }
            }catch (InputMismatchException e) {
                System.out.println("\n\tDebes teclear un número entero...");
            }
        }
        while (opcion != 6);
    }
}