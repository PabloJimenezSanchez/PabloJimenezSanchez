import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class metodos {

    Scanner entrada = new Scanner(System.in);

    public void caso1(){
        try {
            int numAbon;
            String nombreCli;
            float valorFac;

            FileOutputStream fichero = new FileOutputStream("src/facturas_telf.dat", true);
            DataOutputStream fich = new DataOutputStream(fichero);

            System.out.println("\nAlta de factura");
            System.out.print("\n\tNúmero de abonado: ");
            numAbon = entrada.nextInt();
            fich.writeInt(numAbon);

            System.out.print("\tNombre: ");
            nombreCli = entrada.next();
            fich.writeUTF(nombreCli);

            System.out.print("\tValor de la factura: ");
            valorFac = entrada.nextFloat();
            fich.writeFloat(valorFac);

            fichero.close();
            fich.close();
            System.out.println("\n\t\tDatos incorporados al fichero");
        }catch (IOException e) {
            System.out.println("\nError al crear el fichero...");
        }
    }

    public void caso2() {
        try {
            int numAbonBus, auxNumAbon;
            boolean numAbonEn=false;
            File fichero = new File("src/facturas_telf.dat");
            RandomAccessFile fich = new RandomAccessFile(fichero, "rw");
            fich.seek(0);
            System.out.println("\nModificación del valor de factura");
            System.out.print("\n\tNúmero del abonado: ");
            numAbonBus = entrada.nextInt();
            while (fich.getFilePointer() < fich.length()) {
                auxNumAbon = fich.readInt();
                fich.readUTF();
                if (auxNumAbon == numAbonBus) {
                    long pos = fich.getFilePointer();
                    float auxFactura = fich.readFloat();
                    System.out.println("\t\tValor de la factura: " + auxFactura + " €");
                    System.out.print("\n\tNuevo valor de la factura: ");
                    fich.seek(pos);
                    float nuevafactura = entrada.nextFloat();
                    fich.writeFloat(nuevafactura);
                    System.out.println("\n\tDatos modificados en el fichero...");
                    numAbonEn=true;
                } else {
                    fich.readFloat();
                }
            }
            if (numAbonEn==false) {
                System.out.println("\n\t\tAbonado no encontrado...");
            }
            fich.close();
        }catch (IOException e) {
            System.out.println("\n\tSe ha producido un error en la lectura o escritura en el fichero...");
        }
    }

    public void caso3() {
        try {
            int numAbonBus, auxNumAbon;
            boolean numAbonEn=false;
            File fichero = new File("src/facturas_telf.dat");
            RandomAccessFile fich = new RandomAccessFile(fichero, "r");
            fich.seek(0);
            System.out.println("Consulta facturación abonado");
            System.out.print("\n\tNúmero del abonado: ");
            numAbonBus = entrada.nextInt();
            while (fich.getFilePointer() < fich.length()) {
                auxNumAbon = fich.readInt();
                fich.readUTF();
                if (auxNumAbon == numAbonBus) {
                    float auxFactura = fich.readFloat();
                    System.out.println("\n\t\tValor de la factura: " + auxFactura + " €");
                    numAbonEn=true;
                } else {
                    fich.readFloat();
                }
            }
            if (numAbonEn==false) {
                System.out.println("\n\t\tAbonado no encontrado...");
            }
            fich.close();
        }catch (IOException e) {
            System.out.println("\n\tSe ha producido un error en la lectura o escritura en el fichero...");
        }
    }

    public void caso4() {
        try {
            float auxValorFac, facTotal=0;
            File fichero = new File("src/facturas_telf.dat");
            RandomAccessFile fich = new RandomAccessFile(fichero, "r");
            fich.seek(0);
            System.out.println("\n\nConsulta facturación total");
            while (fich.getFilePointer() < fich.length()) {
                fich.readInt();
                fich.readUTF();
                auxValorFac = fich.readFloat();
                facTotal = facTotal+auxValorFac;
            }
            fich.close();
            System.out.println("\n\tFacturación: "+String.format("%10.2f",facTotal)+" €");
        } catch (IOException e) {
            System.out.println("\n\tSe ha producido un error en la lectura o escritura en el fichero...");
        }
    }

    public void caso5() {

        File fichero = new File("src/facturas_telf.dat");

        if (fichero.delete()) {
            System.out.println("\n\tFichero eliminado...");
        }
        else {
            System.out.println("\nNo se ha podido eliminar el fichero...");
        }
    }

    public int excepcion1() throws InputMismatchException {
        Scanner entrada = new Scanner(System.in);

        int opcion = entrada.nextInt();
        return opcion;
    }
}